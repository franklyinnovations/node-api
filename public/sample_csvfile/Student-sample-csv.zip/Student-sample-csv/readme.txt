Student CSV Upload Instructions-
===============================

Source : https://www.pateast.co/

Total Fields - 30

"Enrollment No": Required,
"Roll No": Optional,
"Form No": Optional,
"Fee Receipt No": Optional,
"Admission Date":Required [Format - yyyy-mm-dd] EX - 2017-09-06
"Full Name":Required,
"Gender": Required,[Format - male/female]
"Mobile Number":Required,[Format - 10 digit mobile number]
"Email":Required,
"Religion":Optional, [EX - Hindu]
"Height":Optional, [EX - 5ft 6in]
"Birthmark":Optional,
"Blood Group": Optional, [Format - A+,A-,B+,B-,O+,O-,AB+,AB-]
"Communication Address":Required,
"Permanent Address":Required.
"Date of Birth":Required [Format - yyyy-mm-dd] EX - 1995-09-06
"Nationality":Required,[EX - Indian]
"Father Name":Required,
"Father Contact":Required [Format - 10 digit mobile number]
"Father’s Alternate Contact":Optional [Format - 10 digit mobile number]
"Mother Name":Required,
"Mother Contact":Optional [Format - 10 digit mobile number]
"Mother’s Alternate Contact":Optional [Format - 10 digit mobile number]
"Guardian name":Optional,
"Guardian Relationship":Optional,
"Guardian Contact":Optional [Format - 10 digit mobile number]
"Guardian’s Alternate Contact(Optional)":Optional [Format - 10 digit mobile number]
"Guardian Address(Optional)":Optional,
"Pre Organization Name":Optional,
"Pre Organization Address":Optional,
"Pre Qualification":Optional"




